## Namaste React Course by Akshay Saini

# Episode 13 - Time for the Test

## Theory Assignment:

- What are the difference types of Testing?
- React Testing Library and It's set up
- What is Jest and why do we use it?
- Jest setup and installation of it's related

## Coding Assignment:

- Setup React Testing Library
- Write Unit Tests for Contact, RestaurantCard components
- Write an Integration Test Case for the Search Feature on the Homepate
- Write Integration Test for Add to Cart flow
