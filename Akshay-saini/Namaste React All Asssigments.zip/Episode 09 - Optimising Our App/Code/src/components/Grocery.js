const Grocery = () => {
  return (
    <h1 style={{ textAlign: 'center', marginTop: '100px' }}>
      Our Grocery Online Store, we have a lot of child components inside this
      web page
    </h1>
  );
};

export default Grocery;
