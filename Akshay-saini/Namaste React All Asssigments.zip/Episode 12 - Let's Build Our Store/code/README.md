## Namaste React Course by Akshay Saini

# Episode 12 - Let's Build Our Store

## Coding Assignment:

- Practice React Context with code examples
- Try out Nested Contexts

## References:

- [Lifting State Up](https://react.dev/learn/sharing-state-between-components#lifting-state-up-by-example)
- [React Context](https://react.dev/reference/react/useContext)
