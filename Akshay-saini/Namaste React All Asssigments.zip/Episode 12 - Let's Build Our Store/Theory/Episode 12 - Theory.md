## Namaste React Course by Akshay Saini

# Episode 12 - Let's Build Our Store

## Theory Assignment:

- Advantages of using Redux Toolkit over Redux
- Explain Dispatcher.
- Explain Reducer.
- Explain Slice.
- Explain Selector.
- Explain createSlice and the configuration it takes.
